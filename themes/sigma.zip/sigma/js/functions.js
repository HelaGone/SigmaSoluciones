$(document).ready(function(){
	'use strict';
	console.log('functions js');

	/*
	 * Vanilla JS
	*/


	/*
	 * jQuery
	*/

});
