<form role="search" method="get" id="searchform" class="searchform" action="<?php echo home_url('/'); ?>">
	<div class="sig_form_wrapper">
		<input type="text" value="" name="s" id="s"/>
		<!-- <input type="submit" id="searchsubmit" value="Search"> -->
    <input type="image" alt="Submit search query" src="<?php echo THEMEPATH .'images/assets/search-24px.svg'; ?>">
	</div>
</form>
